	
function unlock(){	
console.log("Tubecomments access from extenstion html page.");
}

 